"""Request-placement controller boundary."""
