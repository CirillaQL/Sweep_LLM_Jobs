"""Canary scheduler: when to run the tier locator, when to stop it.

The Canary is an ordinary production group whenever it is not experimenting.

Start (all of):
* a trigger: cold start or a table without a cluster model (full calibration;
  production runs at MAX and admits everything meanwhile), production violations
  drifting above theta (relocation), a verification (the length distribution
  shifted by more than `length_shift`, or the Controller's plan runs a point at a
  per-group rate the Canary has not confirmed), or the periodic neighbour check;
* the rest of the pool can carry production: no pressure for `quiet_s`, and the
  solver finds the active groups without the Canary feasible for the demand;
* budget: `min_interval_s` since the last experiment and at most `max_duty` of
  the time spent experimenting.
The Canary then drains (no new requests; in-flight ones finish) and explores.

A verification is one window at the plan's point and per-group rate with the
current length mix: a pass records the rate as confirmed, a failure caps the
point below that rate in the model (the solver then avoids it).

Stop: in best-effort mode any SLO/capacity pressure reclaims Canary, including
cold calibration. Cancel and join probes, then confirm both vLLM nodes idle before
returning the group at MAX. A failed drain leaves it EXPLORING and is retried.
No experiment starts while full effort is active. Legacy policies keep their
incremental recovery. Aborted locator windows are cached for a later retry.
"""

import asyncio
import time
from collections.abc import Callable, Mapping
from dataclasses import dataclass
from typing import Any

from canatune.controller.locator import LocatorError, TierLocator, wilson_ucb
from canatune.controller.tier_controller import TierController
from canatune.domain.groups import Group, GroupState, Tier
from canatune.domain.load import LengthStats, LengthSummary


@dataclass(frozen=True)
class SchedulerSettings:
    period_s: float = 1.0
    quiet_s: float = 60.0
    min_interval_s: float = 600.0
    max_duty: float = 0.10
    periodic_s: float = 1800.0
    length_shift: float = 0.30
    drift_min_samples: int = 200
    drain_timeout_s: float = 30.0
    # False: no experiment after the first publish (no recheck, drift relocation or
    # verification). An evaluation switch: runs that vary the clocks themselves (a clock
    # grid) must not have the Canary move the table under them.
    recalibrate: bool = True

    @classmethod
    def from_config(cls, config: Mapping[str, Any]) -> "SchedulerSettings":
        raw = {k: v for k, v in config.get("canary", {}).items() if k in cls.__dataclass_fields__}
        return cls(**raw)


class CanaryScheduler:
    def __init__(
        self,
        controller: TierController,
        locator: TierLocator | None,
        lengths: LengthStats,
        settings: SchedulerSettings,
        *,
        theta: float,
        clock: Callable[[], float] = time.monotonic,
    ) -> None:
        self.controller = controller
        self.locator = locator
        self.lengths = lengths
        self.s = settings
        self.theta = theta
        self._clock = clock
        self._t0 = clock()
        self.task: asyncio.Task | None = None
        self.kind: str | None = None
        self.reason: str | None = None
        self.last_end: float | None = None
        self.explore_s = 0.0
        self._started_at: float | None = None
        self._rejections_seen = controller.router.pressure
        self._last_rejection_at = float("-inf")
        self._reference: LengthSummary | None = None
        self._draining_since: float | None = None
        self._pending: tuple[str, str] | None = None
        self.history: list[dict[str, Any]] = []
        self.verified: dict[str, float] = {}  # point -> highest per-group rate confirmed
        controller.on_pressure = self.abort
        controller.reclaim_canary = self.reclaim

    @property
    def canary(self) -> Group | None:
        return next((g for g in self.controller.groups if g.canary), None)

    @property
    def running(self) -> bool:
        return self.task is not None and not self.task.done()

    # ---- conditions -----------------------------------------------------------------

    def _note_rejections(self) -> None:
        rejections = self.controller.router.pressure  # rejections + overflows
        if rejections != self._rejections_seen:
            self._rejections_seen = rejections
            self._last_rejection_at = self._clock()

    def trigger(self) -> tuple[str, str] | None:
        """-> (kind, reason): kind is "full", "relocate", "verify" or "recheck"."""
        table = self.controller.tiers.table
        if table is None:
            return "full", "cold_start"
        if not self.s.recalibrate:
            return None
        if self.controller.settings.solver and self.controller.tiers.model_json() is None:
            return "full", "no_model"
        if self._reference is not None and not self.lengths.using_default:
            if self.lengths.summary().shifted(self._reference, self.s.length_shift):
                return "verify", "length_shift"
        if self._unverified() is not None:
            return "verify", "plan"
        outcomes = self.controller.router.outcomes
        if len(outcomes) >= self.s.drift_min_samples:
            k = sum(outcomes)
            # Lower confidence bound above theta: production really violates more.
            if (
                k / len(outcomes) > self.theta
                and 1 - wilson_ucb(len(outcomes) - k, len(outcomes), 1.28) > self.theta
            ):
                return "relocate", "violation_drift"
        last = self.last_end if self.last_end is not None else self._t0
        if self._clock() - last >= self.s.periodic_s:
            return "recheck", "periodic"
        return None

    def may_start(self) -> tuple[bool, str]:
        if self.controller.mode != "energy":
            return False, self.controller.mode
        if self.canary is not None and self.canary.state is GroupState.EXPLORING:
            # Cold start deliberately claims the Canary before its first run.
            if self.task is not None:
                return False, "awaiting_drain"
        table = self.controller.tiers.table
        now = self._clock()
        if table is None:
            # Cold start: go at once; after a failed attempt retry every quiet_s.
            if self.last_end is not None and now - self.last_end < self.s.quiet_s:
                return False, "cold_start_retry_wait"
            return True, "cold_start"
        if self.last_end is not None and now - self.last_end < self.s.min_interval_s:
            return False, "min_interval"
        elapsed = max(now - self._t0, 1.0)
        if self.explore_s / elapsed > self.s.max_duty:
            return False, "duty_budget"
        if now - self._last_rejection_at < self.s.quiet_s:
            return False, "recent_rejections"
        canary = self.canary
        if canary is None:
            return False, "no_canary"
        others = [
            g
            for g in self.controller.groups
            if g is not canary and g.state is GroupState.ACTIVE and g.effective is not None
        ]
        if not others:
            return False, "no_other_active_group"
        if self.controller.solver() is not None and not self.controller.can_carry(len(others), now):
            return False, "others_cannot_carry"
        return True, "ok"

    def _unverified(self) -> tuple[Any, float] | None:
        """(point, per-group rate) of the current plan when the Canary has not seen
        that point feasible at that rate; None otherwise."""
        plan = self.controller.plan
        if plan is None or not plan.feasible:
            return None
        rate, _, _ = self.controller.demand(self._clock())
        per_group = max(plan.rates, default=rate / max(plan.n, 1))
        if per_group <= self.verified.get(plan.point.key(), 0.0):
            return None
        return plan.point, per_group

    # ---- control --------------------------------------------------------------------------

    def abort(self, reason: str) -> bool:
        """Called by the Controller under pressure it cannot relieve otherwise;
        -> whether an experiment (running or about to start) was stopped."""
        if (
            self.controller.tiers.table is None
            and self.controller.router.settings.overload != "best_effort"
        ):
            return False  # cold start: production is at MAX and admits everything
        stopped = False
        if self.running:
            assert self.task is not None
            self.task.cancel()
            self.controller.log.write({"event": "canary_abort", "reason": reason})
            stopped = True
        if self._pending is not None:
            self._pending = None
            stopped = True
            canary = self.canary
            if canary is not None and canary.state is GroupState.DRAINING:
                canary.state = GroupState.ACTIVE
        return stopped

    async def reclaim(self) -> None:
        """Join experiment cleanup, then confirm vLLM drained before serving."""
        if self.running and self.task is not asyncio.current_task():
            assert self.task is not None
            self.task.cancel()
            await asyncio.gather(self.task, return_exceptions=True)
        self._pending = None
        canary = self.canary
        if canary is not None and canary.state is GroupState.EXPLORING:
            if self.locator is not None:
                quiesce = getattr(self.locator.backend, "quiesce", None)
                if quiesce is not None:
                    await quiesce()
            canary.state = GroupState.ACTIVE
            canary.effective = None  # Controller must confirm MAX before routing

    def request(self, kind: str, reason: str) -> tuple[bool, str]:
        """Manual start through the control API (start conditions still apply)."""
        if self.running or self._pending is not None:
            return False, "already_running"
        ok, why = self.may_start()
        if ok:
            self._begin(kind, reason)
        return ok, why

    def _begin(self, kind: str, reason: str) -> None:
        canary = self.canary
        if canary is None or self.locator is None:
            return
        self._pending = (kind, reason)
        if canary.state is GroupState.ACTIVE:
            canary.state = GroupState.DRAINING  # no new production requests
            self._draining_since = self._clock()
        self.controller.log.write(
            {"event": "canary_claim", "kind": kind, "reason": reason, "state": canary.state.value}
        )

    async def step(self) -> None:
        self._note_rejections()
        canary = self.canary
        if canary is None or self.locator is None or self.running:
            return
        if self.task is not None and canary.state is GroupState.EXPLORING:
            await self.reclaim()  # retry a failed drain before permitting another experiment
            if not self.controller.router.full_effort:
                await self.controller.set_tier(
                    canary, Tier.H if self.controller.tiers.table is not None else Tier.MAX,
                    "canary_drained",
                )
        if self._pending is None:
            trig = self.trigger()
            if trig is None:
                return
            ok, _ = self.may_start()
            if not ok:
                return
            self._begin(*trig)
        # Wait until the Canary has no production request in flight.
        if canary.state is GroupState.DRAINING and canary.n_inflight:
            if self._clock() - (self._draining_since or self._clock()) > self.s.drain_timeout_s:
                canary.state = GroupState.ACTIVE  # could not drain: give up this time
                self._pending = None
            return
        assert self._pending is not None
        kind, reason = self._pending
        self._pending = None
        canary.state = GroupState.EXPLORING
        self.kind, self.reason = kind, reason
        self._started_at = self._clock()
        self.task = asyncio.create_task(self._experiment(kind, reason))

    def _prompts(self) -> list[int]:
        pairs = self.lengths.pairs()
        prompts = sorted(p for p, _ in pairs)
        # Include the longest prompt: lengths that miss the SLO even when idle must be
        # found here, or they poison every later window.
        picks = {prompts[int(q * (len(prompts) - 1))] for q in (0.1, 0.3, 0.5, 0.7, 0.9)}
        picks.add(prompts[-1])
        if len(picks) < 2:
            only = next(iter(picks))
            picks = {max(1, only // 2), only, only * 2}
        return sorted(picks)

    async def _experiment(self, kind: str, reason: str) -> None:
        assert self.locator is not None
        controller = self.controller
        table = controller.tiers.table
        outcome = "failed"
        error_text = None
        try:
            summary = self.lengths.summary()
            if kind == "verify" and table is not None:
                ok = await self._verify()
                self._reference = summary
                outcome = "verified" if ok else "verification_failed"
                return
            if kind == "recheck" and table is not None:
                new = await self.locator.recheck(table, self._prompts())
            else:
                if kind == "relocate" or reason == "length_shift":
                    self.locator.forget()  # old windows used another workload
                new = await self.locator.locate(
                    summary.prompt_mean,
                    self._prompts(),
                    previous=table if kind == "relocate" else None,
                )
            self._reference = summary
            controller.router.outcomes.clear()
            await controller.publish(new, reason)
            self.verified = {}
            capacity = new.evidence.get("capacity_rps")
            if capacity:  # the fill windows confirmed H up to C_H
                self.verified[new.h.key()] = float(capacity)
            outcome = "published"
        except asyncio.CancelledError:
            outcome = "aborted"
        except LocatorError as error:
            error_text = str(error)
            controller.log.write({"event": "locator_error", "error": error_text})
        except Exception as error:  # probes hit real services: never kill the control loop
            error_text = repr(error)
            controller.log.write({"event": "locator_error", "error": error_text})
        finally:
            now = self._clock()
            self.explore_s += now - (self._started_at or now)
            self.last_end = now
            self.history.append(
                {
                    "kind": kind,
                    "reason": reason,
                    "outcome": outcome,
                    "end": now,
                    "error": error_text,
                }
            )
            canary = self.canary
            if canary is not None and not controller.router.full_effort:
                try:
                    await self.reclaim()
                except Exception as error:
                    controller.log.write({"event": "canary_drain_error", "error": repr(error)})
                else:
                    await controller.set_tier(
                        canary, Tier.H if (
                            controller.tiers.table is not None and not controller.router.full_effort
                        ) else Tier.MAX,
                        f"canary_{outcome}",
                    )

    async def _verify(self) -> bool:
        """Layer 3: the plan's point at its per-group rate, current length mix."""
        assert self.locator is not None
        controller = self.controller
        target = self._unverified()
        if target is None:  # a length shift: re-check the current plan as it is
            plan = controller.plan
            if plan is None:
                return False
            rate, _, _ = controller.demand(self._clock())
            target = (plan.point, max(plan.rates, default=rate / max(plan.n, 1)))
        point, per_group = target
        # Verification must replay all offered lengths, including prompts that
        # calibration classified as impossible at idle; otherwise the rate is wrong.
        self.locator.backend.set_prompt_limit(None)
        self.locator.mean_prompt = self.lengths.summary().prompt_mean
        w = await self.locator.verify(point, per_group, controller.tiers.alpha_tokens)
        ok = self.locator.meets_target(w)
        key = point.key()
        controller.log.write(
            {
                "event": "canary_verify",
                "point": key,
                "rate_rps": per_group,
                "ok": ok,
                "requests": w.requests,
                "violations": w.violations,
            }
        )
        if ok:
            self.verified[key] = max(self.verified.get(key, 0.0), per_group)
            return True
        model = controller.tiers.model_json()
        if model is not None:  # the point is infeasible at this rate: cap it below
            caps = model.setdefault("caps", {})
            caps[key] = min(float(caps.get(key, per_group)), per_group)
            if controller.store is not None and controller.tiers.table is not None:
                controller.store.save(controller.tiers.table)
        return False

    async def run(self, stop: asyncio.Event) -> None:
        while not stop.is_set():
            try:
                await self.step()
            except Exception as error:
                self.controller.log.write({"event": "canary_error", "error": repr(error)})
            try:
                await asyncio.wait_for(stop.wait(), timeout=self.s.period_s)
            except asyncio.TimeoutError:
                pass
        if self.running:
            assert self.task is not None
            self.task.cancel()
            await asyncio.gather(self.task, return_exceptions=True)

    def state(self) -> dict[str, Any]:
        run = None if self.locator is None else self.locator.run
        return {
            "running": self.running,
            "kind": self.kind,
            "reason": self.reason,
            "pending": self._pending,
            "phase": None if run is None else run.phase,
            "windows": None if run is None else run.windows,
            "reused_windows": None if run is None else run.reused,
            "explore_s": self.explore_s,
            "history": self.history[-20:],
            "lengths_default": self.lengths.using_default,
        }
