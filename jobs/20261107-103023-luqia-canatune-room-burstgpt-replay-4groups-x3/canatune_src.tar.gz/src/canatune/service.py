"""Assemble groups, tables, telemetry, Router, Controller and Canary from config."""

import asyncio
import json
import os
from collections.abc import Callable, Mapping
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import httpx

from canatune.config import P2P_NCCL_CONNECTOR, kv_connector
from canatune.controller.canary import CanaryScheduler, SchedulerSettings
from canatune.controller.locator import (
    AdmissionInputs,
    LocatorSettings,
    ProbeBackend,
    TierLocator,
)
from canatune.controller.probe import CanaryProbe, ProbeSettings
from canatune.controller.router import CanaTuneRouter, RouterSettings
from canatune.controller.tier_controller import ControllerSettings, TierController
from canatune.domain.admission import SlackRisk, slack_edges
from canatune.domain.groups import (
    ClockPoint,
    Group,
    GroupState,
    Tier,
    TierState,
    TierStore,
    TierTableError,
)
from canatune.domain.load import LengthStats
from canatune.domain.risk import RiskTable, RiskTableError
from canatune.infrastructure.clocks import (
    AgentClockActuator,
    ClockActuator,
    GpuRef,
    NullClockActuator,
    gpu_refs,
)
from canatune.infrastructure.records import JsonlLog
from canatune.infrastructure.telemetry import Telemetry
from canatune.proxy.proxy import parse_endpoints


@dataclass
class Runtime:
    """Everything the proxy needs for the `cantune` routing policy."""

    groups: list[Group]
    router: CanaTuneRouter
    controller: TierController
    canary: CanaryScheduler
    telemetry: Telemetry | None
    events: JsonlLog
    tiers: TierState
    lengths: LengthStats
    tasks: list[asyncio.Task] = field(default_factory=list)
    stop: asyncio.Event = field(default_factory=asyncio.Event)

    async def discover_max(self) -> None:
        """MAX = highest clocks the Canary pair's agents report (unknown cluster);
        the configured values stay when clock control is off."""
        canary = self.canary.canary
        refs = self.controller.gpu_refs
        if canary is None or canary.prefill not in refs or canary.decode not in refs:
            return
        try:
            p = await self.controller.actuator.supported_clocks(refs[canary.prefill])
            d = await self.controller.actuator.supported_clocks(refs[canary.decode])
        except Exception as error:
            self.events.write({"event": "max_clock_error", "error": repr(error)})
            return
        if p and d:
            self.tiers.max_point = ClockPoint(max(p), max(d))
            self.events.write({"event": "max_clock", "clock": self.tiers.max_point.key()})

    async def start(self) -> None:
        await self.discover_max()
        await self.controller.start()
        canary = self.canary.canary
        if self.canary.locator is None and canary is not None:
            # No agents, no calibration: the Canary serves like any production group.
            if canary.state is GroupState.EXPLORING:
                canary.state = GroupState.ACTIVE
                await self.controller.set_tier(canary, Tier.MAX, "no_locator")
        if self.telemetry is not None:
            self.tasks.append(asyncio.create_task(self.telemetry.run(self.stop)))
        self.tasks.append(asyncio.create_task(self.controller.run(self.stop)))
        self.tasks.append(asyncio.create_task(self.canary.run(self.stop)))

    async def shutdown(self) -> None:
        self.stop.set()
        await asyncio.gather(*self.tasks, return_exceptions=True)
        self.router.table.save()
        self.router.slack.save()


def identity(config: Mapping[str, Any]) -> dict[str, Any]:
    """Configuration identity of the risk and tier tables: a change starts new ones.
    The SLO is part of it: H, the capacities, B* / the D capacity and the recorded
    violations are all measured against it."""
    slo = config["experiment"]["slo"]
    return {
        "model": config["model"]["name"],
        "vllm_version": config["runtime"].get("vllm_version"),
        "connector": kv_connector(config),
        "send_type": config["kv_transfer"].get("prefill_send_type")
        if kv_connector(config) == P2P_NCCL_CONNECTOR
        else None,
        "prefill_gpu": config["topology"]["prefill_nodegroup"]["gpu_type"],
        "decode_gpu": config["topology"]["decode_nodegroup"]["gpu_type"],
        "max_model_len": config["model"]["max_model_len"],
        "slo": {"ttft_ms": float(slo["ttft_ms"]), "tpot_ms": float(slo["tpot_ms"])},
    }


def build_groups(config: Mapping[str, Any]) -> list[Group]:
    routing = config["routing"]
    groups = [
        Group(
            name="G0",
            prefill=routing["canary_pair"][0],
            decode=routing["canary_pair"][1],
            canary=True,
        )
    ]
    for index, (prefill, decode) in enumerate(routing["production_pairs"], start=1):
        groups.append(Group(name=f"G{index}", prefill=prefill, decode=decode))
    for group in groups:
        group.state = GroupState.PARK
        group.tier = Tier.PARK
    return groups


def configured_max(config: Mapping[str, Any]) -> ClockPoint:
    topology = config["topology"]
    return ClockPoint(
        int(topology["prefill_nodegroup"]["high_frequency_mhz"]),
        int(topology["decode_nodegroup"]["high_frequency_mhz"]),
    )


def cold_start_lengths(config: Mapping[str, Any]) -> list[tuple[int, int]]:
    """(prompt, output) pairs the Canary probes with until real requests finished.

    The output is the service's cap on generated tokens (`canary.max_output_tokens`,
    the largest max_tokens a request may ask for: a deployment policy). Probing
    with the cap is the heaviest decode load, so a cold-start H is conservative;
    real (prompt, output) lengths replace these after `length_min_samples` requests.
    Without the cap, the legacy `canary.default_lengths` pairs are used.
    `canary.default_lengths_file` (JSON list of [prompt, output]) replaces all of these:
    an expected length distribution known before the first request, used as it is."""
    raw = config.get("canary", {})
    cap = raw.get("max_output_tokens")
    legacy = [tuple(pair) for pair in raw.get("default_lengths") or [[512, 64]]]
    lengths_file = raw.get("default_lengths_file")
    if lengths_file:
        pairs = [(int(p), int(o)) for p, o in json.loads(Path(lengths_file).read_text())]
    elif cap is None:
        pairs = [(int(p), int(o)) for p, o in legacy]
    else:
        if isinstance(cap, bool) or not isinstance(cap, int) or cap < 1:
            raise ValueError("canary.max_output_tokens must be a positive integer")
        prompts = raw.get("default_prompts") or [p for p, _ in legacy]
        pairs = [(int(p), cap) for p in prompts]
    limit = config.get("model", {}).get("max_model_len")
    too_long = [pair for pair in pairs if limit is not None and sum(pair) > int(limit)]
    if too_long:
        raise ValueError(f"cold-start lengths exceed model.max_model_len {limit}: {too_long}")
    return pairs


def _env_override(raw: Mapping[str, Any], env: str, key: str) -> Any:
    return os.environ.get(env) or raw.get(key)


def probe_client() -> httpx.AsyncClient:
    """The Canary's client. No connection limit: httpx's default (100) would hold probes
    back here, and a window of more sequences would measure this client, not the GPU."""
    return httpx.AsyncClient(
        timeout=httpx.Timeout(120, connect=5),
        limits=httpx.Limits(max_connections=None, max_keepalive_connections=64),
        trust_env=False,
    )


def build_runtime(
    config: Mapping[str, Any],
    metrics_urls: Mapping[str, str],
    client_factory: Callable[[], httpx.AsyncClient],
    *,
    actuator: ClockActuator | None = None,
    refs: Mapping[str, GpuRef] | None = None,
    probe_backend: ProbeBackend | None = None,
) -> Runtime:
    record_dir = os.environ.get("CANATUNE_RECORD_DIR")
    requests_log = JsonlLog(None if not record_dir else os.path.join(record_dir, "requests.jsonl"))
    events = JsonlLog(None if not record_dir else os.path.join(record_dir, "events.jsonl"))
    ident = identity(config)

    risk_raw = dict(config["risk"])
    risk_raw["path"] = _env_override(risk_raw, "CANATUNE_RISK_TABLE", "path")
    try:
        table = RiskTable.from_config(risk_raw, ident)
    except RiskTableError as error:
        # A table from another configuration is neither reused nor overwritten.
        events.write({"event": "risk_table_ignored", "error": str(error)})
        table = RiskTable.from_config({**risk_raw, "path": None}, ident)

    canary_raw = config.get("canary", {})
    store = TierStore(_env_override(canary_raw, "CANATUNE_TIER_TABLE", "tier_table_path"), ident)
    tiers = TierState(max_point=configured_max(config))
    try:
        tiers.table = store.load()
    except TierTableError as error:
        events.write({"event": "tier_table_ignored", "error": str(error)})
    lengths = LengthStats(
        cold_start_lengths(config),
        min_samples=int(canary_raw.get("length_min_samples", 50)),
    )

    telemetry = None
    if config.get("telemetry", {}).get("enabled", True):
        telemetry = Telemetry(
            metrics_urls,
            period_s=float(config.get("telemetry", {}).get("period_s", 0.25)),
            client_factory=client_factory,
        )

    groups = build_groups(config)
    router_settings = RouterSettings.from_config(config)
    slack = SlackRisk(
        slack_edges(router_settings.ttft_slo_ms),
        min_samples=int(risk_raw.get("min_samples", 20)),
        path=None if not risk_raw.get("path") else f"{risk_raw['path']}.slack.json",
    )
    slack.load()
    router = CanaTuneRouter(
        groups,
        table,
        router_settings,
        tiers,
        lengths=lengths,
        telemetry=telemetry,
        log=requests_log,
        slack=slack,
    )

    clock_control = dict(config.get("clock_control", {}))
    agents = dict(clock_control.get("agents") or {})
    for role, env in (("prefill", "CANATUNE_PREFILL_AGENT"), ("decode", "CANATUNE_DECODE_AGENT")):
        agents[role] = os.environ.get(env) or agents.get(role)
    clock_control["agents"] = agents
    if actuator is None:
        actuator = (
            AgentClockActuator(client_factory)
            if clock_control.get("enabled")
            else NullClockActuator()
        )
    if refs is None:
        refs = (
            gpu_refs({**config, "clock_control": clock_control})
            if clock_control.get("enabled")
            else {}
        )

    controller = TierController(
        groups,
        router,
        ControllerSettings.from_config(config),
        actuator,
        refs,
        tiers,
        store=store,
        log=events,
    )

    locator = None
    canary_group = groups[0]
    if probe_backend is None and canary_group.prefill in refs and canary_group.decode in refs:
        slo = config["experiment"]["slo"]
        probe_backend = CanaryProbe(
            canary_group,
            parse_endpoints(config),
            actuator,
            refs,
            lengths,
            table,
            ProbeSettings.from_config(config),
            client_factory=probe_client,
            telemetry=telemetry,
            ttft_slo_ms=float(slo["ttft_ms"]),
            tpot_slo_ms=float(slo["tpot_ms"]),
            log=events,
        )
    if probe_backend is not None:
        admission = AdmissionInputs(
            kv_bytes_per_token=router_settings.kv_bytes_per_token,
            kv_buffer_bytes=router_settings.kv_buffer_bytes,
        )
        locator = TierLocator(
            probe_backend, LocatorSettings.from_config(config), log=events, admission=admission
        )
    canary = CanaryScheduler(
        controller,
        locator,
        lengths,
        SchedulerSettings.from_config(config),
        theta=router_settings.theta,
    )
    return Runtime(groups, router, controller, canary, telemetry, events, tiers, lengths)
