"""Domain models and contracts."""
