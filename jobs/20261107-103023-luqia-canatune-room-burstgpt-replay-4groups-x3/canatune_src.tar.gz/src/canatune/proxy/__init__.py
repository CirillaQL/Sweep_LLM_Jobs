"""Upstream vLLM proxy boundary."""
