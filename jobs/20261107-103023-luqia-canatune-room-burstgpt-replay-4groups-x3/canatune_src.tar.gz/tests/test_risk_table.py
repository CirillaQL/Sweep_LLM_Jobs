"""Online risk table: buckets, seed, monotone bounds, persistence."""

import pytest

from canatune.config import load_config
from canatune.domain.groups import ClockPoint
from canatune.domain.risk import Buckets, RiskTable, RiskTableError, is_violation
from canatune.service import identity

H = ClockPoint(1815, 1050)
L = ClockPoint(1305, 1050)


def table(**kwargs) -> RiskTable:
    return RiskTable(Buckets((0, 1, 2, 3, 5), (128, 512, 1024, 2048)), min_samples=3, **kwargs)


def test_bucket_uses_upper_edge() -> None:
    b = Buckets((0, 1, 2, 3, 5), (128, 512, 1024, 2048))
    assert [b.n_await_bucket(n) for n in (0, 1, 3, 4, 5, 6)] == [0, 1, 3, 4, 4, 5]
    assert [b.prompt_bucket(n) for n in (1, 128, 129, 2048, 3000)] == [0, 0, 1, 3, 4]


def test_config_table_starts_empty_and_unknown_is_unsafe() -> None:
    config = load_config()
    t = RiskTable.from_config(config["risk"], identity(config))
    estimate = t.lookup(H, 0, 128, True)
    assert (estimate.source, estimate.risk) == ("unknown", 1.0)


def test_sparse_cell_uses_heavier_bound_and_lighter_floor() -> None:
    t = table()
    heavy = t.cell(L, 3, 1024, False)
    for violated in (False, False, True):  # 1/3 observed, enough samples
        t.record(heavy, violated)
    light = t.cell(L, 0, 128, False)
    for _ in range(3):
        t.record(light, False)
    middle = t.estimate(t.cell(L, 1, 512, False))
    assert middle.source == "heavier_bound"
    assert middle.risk == pytest.approx(1 / 3)
    # A cell heavier than every sample has no upper bound: unsafe.
    assert t.estimate(t.cell(L, 5, 2048, False)).risk == 1.0
    # Other clock points are independent.
    assert t.estimate(t.cell(H, 1, 512, False)).source == "unknown"


def test_idle_decode_is_bounded_by_busy_decode() -> None:
    t = table()
    busy = t.cell(L, 1, 512, True)
    for _ in range(3):
        t.record(busy, False)
    idle = t.estimate(t.cell(L, 0, 128, False))
    assert (idle.source, idle.risk) == ("heavier_bound", 0.0)
    # D busy is never bounded by idle-D samples, but idle-D violations raise it.
    assert t.estimate(t.cell(L, 2, 512, True)).source == "unknown"
    bad = t.cell(L, 0, 128, False)
    for _ in range(3):
        t.record(bad, True)
    assert t.estimate(busy).risk == 1.0


def test_pooled_bound_uses_sparse_heavier_cells() -> None:
    t = RiskTable(Buckets((0, 1, 2, 3, 5), (128, 512, 1024, 2048)), min_samples=20)
    for prompt, n in ((128, 9), (512, 14), (1024, 16)):  # queue 2, D busy: 1 violation
        for k in range(n):
            t.record(t.cell(H, 2, prompt, True), prompt == 1024 and k == 0)
    row = t.estimate(t.cell(H, 2, 128, True))
    assert row.source == "pooled_bound"
    assert row.risk == pytest.approx(1 / 39)
    # Too few samples in the heavier part of the row: still unknown.
    assert t.estimate(t.cell(H, 2, 2048, True)).source == "unknown"
    # Lighter cells never enter the pool.
    assert t.estimate(t.cell(H, 3, 128, True)).source == "unknown"


def test_clock_usable_needs_a_safe_well_sampled_cell() -> None:
    t = table()
    assert not t.clock_usable(L, 0.1)
    cell = t.cell(L, 0, 128, False)
    for _ in range(3):
        t.record(cell, False)
    assert t.clock_usable(L, 0.1)


def test_persistence_roundtrip_and_identity_guard(tmp_path) -> None:
    path = tmp_path / "risk.json"
    t = table(identity={"model": "m"}, path=path)
    cell = t.cell(L, 1, 512, True)
    t.record(cell, True)
    t.lookup(L, 1, 512, True)
    t.save()
    loaded = table(identity={"model": "m"}, path=path)
    loaded.load()
    assert loaded.to_json()["cells"][cell.key()]["admitted"] == 1
    assert cell.key() == "1305/1050|1|1|1"
    assert loaded.exploration_candidates(0.1)[0]["cell"] == cell.key()
    with pytest.raises(RiskTableError):
        table(identity={"model": "other"}, path=path).load()


def test_violation_rule() -> None:
    kw = {"ttft_slo_ms": 500, "tpot_slo_ms": 200}
    assert is_violation(499, 199, **kw) is False
    assert is_violation(500, 10, **kw) is True
    assert is_violation(10, 201, **kw) is True
    assert is_violation(None, 10, **kw) is None


def test_a_new_slo_starts_new_risk_and_tier_tables(tmp_path) -> None:
    from canatune.domain.groups import TierStore, TierTable, TierTableError

    config = load_config()
    old = identity(config)
    config["experiment"]["slo"]["tpot_ms"] = 65
    new = identity(config)
    assert old != new and new["slo"] == {"ttft_ms": 1000.0, "tpot_ms": 65.0}
    store = TierStore(tmp_path / "tiers.json", old)
    store.save(TierTable(park=ClockPoint(900, 450), h=ClockPoint(1815, 1050),
                         capacity_h=3000.0, alpha_tokens=460.0))  # fmt: skip
    with pytest.raises(TierTableError):
        TierStore(tmp_path / "tiers.json", new).load()
    raw = dict(config["risk"], path=str(tmp_path / "risk.json"))
    RiskTable.from_config(raw, old).save()
    with pytest.raises(RiskTableError):
        RiskTable.from_config(raw, new)
